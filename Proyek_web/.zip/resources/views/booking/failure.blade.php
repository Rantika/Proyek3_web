@extends('frontlayout')
@section('content')
<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="row mt-4">
        <div class="col-md-6 offset-3">
            <div class="card border border-danger">
                <div class="card-body">
                    <p class="card-text text-danger text-center">Your payment has been failed!!</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->
@endsection