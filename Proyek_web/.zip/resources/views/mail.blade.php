<h3>Thanks for your query</h3>
<table border="1">
	<tr>
		<th>Full Name</th>
		<td>{{$name}}</td>
	</tr>
	<tr>
		<th>Email</th>
		<td>{{$email}}</td>
	</tr>
	<tr>
		<th>Subject</th>
		<td>{{$subject}}</td>
	</tr>
	<tr>
		<th>Message</th>
		<td>{{$msg}}</td>
	</tr>
</table>