<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Home Page</title>
	<link href="<?php echo e(asset('public/bs5/bootstrap.min.css')); ?>" rel="stylesheet" />
	<script type="text/javascript" src="<?php echo e(asset('/public/vendor/jquery/jquery.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('/public/bs5/bootstrap.bundle.min.js')); ?>"></script>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
	  <div class="container">
	    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Hotel Dermayu</a>
	    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
	      <span class="navbar-toggler-icon"></span>
	    </button>
	    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
	      <div class="navbar-nav ms-auto">
            <a class="nav-link" aria-current="page" href="<?php echo e(url('/')); ?>">Home</a>
	        <a class="nav-link" aria-current="page" href="<?php echo e(url('/')); ?>#services">Service</a>
	        <a class="nav-link" href="<?php echo e(url('/')); ?>#gallery">Gallery</a>
	        <a class="nav-link" href="<?php echo e(url('page/about-us')); ?>">Tentang Hotel</a>
	        <?php if(Session::has('customerlogin')): ?>
	        <a class="nav-link" href="<?php echo e(url('customer/add-testimonial')); ?>">Testimoni</a>
	        <a class="nav-link" href="<?php echo e(url('logout')); ?>">Logout</a>
	        <a class="nav-link btn btn-sm btn-danger" href="<?php echo e(url('booking')); ?>">Booking</a>
	        <?php else: ?>
	        <a class="nav-link" href="<?php echo e(url('login')); ?>">Login</a>
	        <a class="nav-link" href="<?php echo e(url('register')); ?>">Register</a>
	        <a class="nav-link btn btn-sm btn-danger" href="<?php echo e(url('booking')); ?>">Booking</a>
	        <?php endif; ?>
	      </div>
	    </div>
	  </div>
	</nav>
		<main>
			<?php echo $__env->yieldContent('content'); ?>
		</main>
	</body>
</html>
<?php /**PATH C:\xampp\htdocs\Proyek3_web\Proyek_web\resources\views/frontlayout.blade.php ENDPATH**/ ?>